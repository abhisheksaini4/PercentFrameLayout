package abhiandroid.percentframelayout;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button register;
    EditText userName, phoneNo, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // init the View's
        userName = (EditText) findViewById(R.id.userName);
        phoneNo = (EditText) findViewById(R.id.phoneNo);
        password = (EditText) findViewById(R.id.password);
        register = (Button) findViewById(R.id.register);
        // perform setOnClickListener Event on Register Button
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (userName.getText().toString().trim().length() > 0 && phoneNo.getText().toString().trim().length() > 0 && password.getText().toString().trim().length() > 0) {
                    // display a thanks you message with user name
                    Toast.makeText(getApplicationContext(), "Thank You " + userName.getText().toString(), Toast.LENGTH_SHORT).show();
                } else {
                    // display an error message that fill user name and password
                    Toast.makeText(getApplicationContext(), "Please Fill All The Fields.!!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
